CHECKOUT WITH PAYPAL REST API DEMO

1) Download PHP server.
Use a server such as XAMPP (https://www.apachefriends.org/index.html) to be able to host the Demo code sample.

2) Browse to the htdocs directory of xampp. Unzip the downloaded demo code folder and place it in this htdocs directory.

3) Start the Apache server in XAMPP from the XAMPP control panel.

4) Open the website in the browser and access it as: http://my_domain/php_code_folder_name/index.php
   Here, my_domain will be localhost if hosting on your own machine.
   The php_code_folder_name is the name of the folder under which the downloaded code resides ('Checkout' folder in case you have not changed the default name).

5) Read further instructions on the above page you open.