# Milestone 3 README
PayPal, Gmail Login information, other details for this milestone

## Gmail Information
Username: hoosridingemail@gmail.com 

Password: ecommerce1

## PayPal Information
Username: hoosridingemail@gmail.com

Password: ecommerce1

## PHPMailer Information
Jason: Currently using XAMPP on Ubuntu, which may cause some issues on different platforms
  - solution for now: pull the current working code, then it will be removed from version control so local settings don't get messed up all the time


